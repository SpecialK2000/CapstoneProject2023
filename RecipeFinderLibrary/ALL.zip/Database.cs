﻿using System.Data.SqlClient;
using System.Collections.Generic;

namespace RecipeFinderLibrary
{
    public partial class UserDatabase
    {
        // Placeholder methods for database interactions
        public bool IsUsernameTaken(string username) { return false; }
        public void SaveUser(User user) { }
        public User QueryUserByUsername(string username) { return null; }
    }

    public partial class RecipeDatabase
    {
        //public Recipe QueryRecipeByName(string name) { return null; }
        public void SaveRecipe(Recipe recipe) { }
        public void RemoveRecipe(Recipe recipe) { }
        public List<Recipe> QueryRecipesByDietaryRestrictions(List<string> restrictions) { return null; }
        public List<Recipe> QueryBudgetConsciousRecipes(double maxBudget) { return null; }
        public void SaveUserRecipe(User user, Recipe recipe) { }
        public void RemoveUserRecipe(User user, Recipe recipe) { }
        public List<Recipe> GetSavedRecipesForUser(User user) { return null; }
    }


    /*public SQLiteConnection GetConnection()
{
    SQLiteConnectionStringBuilder builder = new SQLiteConnectionStringBuilder();
    builder.DataSource = "localhost"; 
    builder.UserID = "capstone_user";
    builder.Password = "pass@word1";
    builder.InitialCatalog = "RecipeFinder";

    return new SQLiteConnection(builder.ConnectionString);
}*/


    public class Database
    {
        private SqlConnection conn;

        public Database(string connectionString)
        {

            conn = new SqlConnection(connectionString);
        }

        public SqlConnection GetConnection()
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "localhost"; // Or your SQL Server address
            builder.UserID = "capstone_user";
            builder.Password = "pass@word1";
            builder.InitialCatalog = "RecipeFinder";

            return new SqlConnection(builder.ConnectionString);
        }
        public bool QueryByUsername(string username, string password)
        {
            conn.Open();
            using (var cmd = new SqlCommand($"SELECT TOP 1 FROM Users WHERE Username = @username AND Password = @password", conn))
            {
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue ("password", password);
                int userCount = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();
                return userCount > 0;
            }
        }

        public void SaveUser(User user)
        {
            conn.Open();
            using (var cmd = new SqlCommand("INSERT INTO Users (Username, Password) VALUES (@username, @password)", conn))
            {
                cmd.Parameters.AddWithValue("@username", user.Username);
                cmd.Parameters.AddWithValue("@password", user.Password);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void SaveRecipe(Recipe recipe)// Does this method save a recipe to the database or save to a user library? Ask Kevin.
        {
            conn.Open();
            using (var cmd = new SqlCommand("INSERT INTO Recipes (Name, Ingredients, CookTime) VALUES (@name, @ingredients, @cookTime)", conn))
            {
                cmd.Parameters.AddWithValue("@name", recipe.Name);
                cmd.Parameters.AddWithValue("@ingredients", recipe.Ingredients);
                cmd.Parameters.AddWithValue("@cookingTime", recipe.CookingTime);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public List<Recipe> QueryByDietaryRestriction(string restriction)
        {
            List<Recipe> recipes = new List<Recipe>();
            conn.Open();
            using (var cmd = new SqlCommand($"SELECT * FROM Recipes WHERE DietaryRestriction = @restriction", conn))
            {
                cmd.Parameters.AddWithValue("@restriction", restriction);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        recipes.Add(new Recipe { /* initialize with data from reader */ });
                    }
                }
                conn.Close();
            }
            return recipes;
        }

        public List<Recipe> QueryByBudget(double budget)
        {
            List<Recipe> recipes = new List<Recipe>();
            conn.Open();
            using (var cmd = new SqlCommand($"SELECT * FROM Recipes WHERE Budget <= @budget", conn))
            {
                cmd.Parameters.AddWithValue("@budget", budget);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        recipes.Add(new Recipe { /* initialize with data from reader */ });
                    }
                }
                conn.Close();
            }
            return recipes;
        }
    }
    }