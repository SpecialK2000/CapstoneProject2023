﻿namespace RecipeFinderLibrary
{
    public class UserDataHandler
    {
        public User AddSavedRecipeToUser(string recipe, User user)
        {
            user.SavedRecipes.Add(recipe);

            return user;
        }

        public User RemoveSavedRecipeFromUser(string recipe, User user)
        {
            user.SavedRecipes.Remove(recipe);

            return user;
        }
    }
}